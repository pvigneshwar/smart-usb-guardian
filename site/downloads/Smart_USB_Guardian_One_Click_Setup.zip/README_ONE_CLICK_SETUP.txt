SMART USB GUARDIAN - ONE CLICK MONITOR SETUP

1. Extract this ZIP.
2. Double-click SETUP_USB_MONITOR.bat.
3. Insert a registered pendrive containing Open Secure USB.exe, usb_guardian.id, and secure_data.hc.

The monitor installs for the current Windows user and starts automatically at sign-in.
