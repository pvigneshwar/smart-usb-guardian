@echo off
setlocal
set "INSTALL_DIR=%LOCALAPPDATA%\SmartUSBGuardian"
set "TARGET=%INSTALL_DIR%\USBMonitor.exe"
set "SOURCE=%~dp0USBMonitor.exe"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SHORTCUT=%STARTUP%\Smart USB Guardian Monitor.lnk"

if not exist "%SOURCE%" (
  echo USBMonitor.exe is missing from this setup folder.
  pause
  exit /b 1
)

taskkill /IM USBMonitor.exe /F >nul 2>&1
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /Y "%SOURCE%" "%TARGET%" >nul

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%SHORTCUT%');$s.TargetPath='%TARGET%';$s.WorkingDirectory='%INSTALL_DIR%';$s.Save()"
start "" "%TARGET%"

echo.
echo Smart USB Guardian Monitor installed and started.
echo Installed at: %TARGET%
pause
