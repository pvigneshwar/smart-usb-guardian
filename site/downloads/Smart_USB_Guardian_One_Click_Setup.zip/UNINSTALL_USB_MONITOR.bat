@echo off
setlocal
set "INSTALL_DIR=%LOCALAPPDATA%\SmartUSBGuardian"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
taskkill /IM USBMonitor.exe /F >nul 2>&1
del /Q "%STARTUP%\Smart USB Guardian Monitor.lnk" >nul 2>&1
rmdir /S /Q "%INSTALL_DIR%" >nul 2>&1
echo Smart USB Guardian Monitor uninstalled.
pause
