SMART USB GUARDIAN - VAULT-ONLY WINDOWS USB PACKAGE

REQUIRED PENDRIVE ROOT:
- Open Secure USB.exe
- usb_guardian.id
- secure_data.hc

1. Register the USB on the owner website.
2. Download usb_guardian.id separately.
3. Create a VeraCrypt container named secure_data.hc.
4. Keep every private file inside secure_data.hc.
5. Double-click PREPARE_VAULT_ONLY_USB.cmd to copy and verify the three root files.

When the application is opened manually, an activation event is recorded.
When the Windows Monitor is installed, insertion is detected automatically.
